from django import forms

from .models import MedicalReport, MedicalRequest


class MedicalRequestForm(forms.ModelForm):
    class Meta:
        model = MedicalRequest
        fields = (
            "request_type",
            "description",
            "phone",
            "location",
            "hospital",
            "blood_group",
            "blood_bags",
            "needed_at",
        )
        widgets = {
            "needed_at": forms.DateTimeInput(attrs={"type": "datetime-local"}),
        }


class MedicalReportForm(forms.ModelForm):
    class Meta:
        model = MedicalReport
        fields = ("reason",)
