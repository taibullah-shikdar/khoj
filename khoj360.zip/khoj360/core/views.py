from django.contrib.auth.decorators import login_required
from django.http import JsonResponse
from django.shortcuts import render

from medical.models import MedicalRequest
from repair.models import RepairRequest

from .models import Hotline, NearbyNews


def home(request):
    notification_count = 0
    if request.user.is_authenticated:
        notification_count = request.user.notifications.filter(is_read=False).count()
    open_medical_requests = MedicalRequest.objects.filter(
        is_public=True,
        status=MedicalRequest.STATUS_OPEN,
    )[:2]
    open_repair_requests = RepairRequest.objects.filter(status=RepairRequest.STATUS_OPEN)[:1]
    context = {
        "hotlines": Hotline.objects.filter(is_active=True),
        "news_items": NearbyNews.objects.filter(is_active=True)[:5],
        "open_medical_count": MedicalRequest.objects.filter(is_public=True, status=MedicalRequest.STATUS_OPEN).count(),
        "open_repair_count": RepairRequest.objects.filter(status=RepairRequest.STATUS_OPEN).count(),
        "open_medical_requests": open_medical_requests,
        "open_repair_requests": open_repair_requests,
        "notification_count": notification_count,
    }
    return render(request, "core/home.html", context)


@login_required
def notification_count(request):
    unread_notifications = request.user.notifications.filter(is_read=False)
    return JsonResponse(
        {
            "count": unread_notifications.count(),
            "emergency_count": unread_notifications.filter(title__icontains="emergency").count(),
        }
    )
