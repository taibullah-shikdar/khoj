def notification_counts(request):
    if not request.user.is_authenticated:
        return {
            "unread_notification_count": 0,
            "unread_emergency_count": 0,
        }

    unread_notifications = request.user.notifications.filter(is_read=False)
    return {
        "unread_notification_count": unread_notifications.count(),
        "unread_emergency_count": unread_notifications.filter(title__icontains="emergency").count(),
    }
