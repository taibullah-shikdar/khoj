from django.urls import path

from . import views


app_name = "core"

urlpatterns = [
    path("", views.home, name="home"),
    path("notifications/count/", views.notification_count, name="notification_count"),
]
