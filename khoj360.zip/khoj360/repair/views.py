from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from accounts.models import Profile

from .forms import RepairRequestForm
from .models import RepairRequest


@login_required
def create_request(request):
    if request.method == "POST":
        form = RepairRequestForm(request.POST)
        if form.is_valid():
            repair_request = form.save(commit=False)
            repair_request.requester = request.user
            repair_request.save()
            return redirect("repair:my_requests")
    else:
        form = RepairRequestForm()
    return render(request, "repair/request_form.html", {"form": form})


@login_required
def open_requests(request):
    requests = RepairRequest.objects.filter(status=RepairRequest.STATUS_OPEN)
    profile = getattr(request.user, "profile", None)
    can_accept = bool(profile and profile.is_repair_provider)
    selected_request = None
    selected_pk = request.GET.get("selected")
    if selected_pk:
        selected_request = requests.filter(pk=selected_pk).first()
    if selected_request is None:
        selected_request = requests.first()
    return render(
        request,
        "repair/open_requests.html",
        {
            "requests": requests,
            "can_accept": can_accept,
            "selected_request": selected_request,
        },
    )


@login_required
def my_requests(request):
    requests = RepairRequest.objects.filter(requester=request.user)
    return render(request, "repair/my_requests.html", {"requests": requests})


@login_required
def accept_request(request, pk):
    repair_request = get_object_or_404(RepairRequest, pk=pk, status=RepairRequest.STATUS_OPEN)
    profile = getattr(request.user, "profile", None)
    if request.method == "POST" and profile and profile.is_repair_provider:
        repair_request.accepted_by = request.user
        repair_request.status = RepairRequest.STATUS_ACCEPTED
        repair_request.save()
    return redirect("repair:open_requests")


@login_required
def mark_done(request, pk):
    repair_request = get_object_or_404(RepairRequest, pk=pk, accepted_by=request.user)
    if request.method == "POST":
        repair_request.status = RepairRequest.STATUS_DONE
        repair_request.save()
    return redirect("repair:open_requests")


@login_required
def confirm_done(request, pk):
    repair_request = get_object_or_404(RepairRequest, pk=pk, requester=request.user, status=RepairRequest.STATUS_DONE)
    if request.method == "POST":
        repair_request.status = RepairRequest.STATUS_CONFIRMED
        repair_request.save()
    return redirect("repair:my_requests")

# Create your views here.
